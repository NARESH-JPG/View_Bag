using System;

namespace Demo_ViewBag_MVC_Core.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }

    public class Student
    {
        public int StudentID { get; set; }
        public string Studentname { get; set; }

        public int Age { get; set; }
        public void Display()
        {
           
            
        }

        public string Count()
        {
            var msg = "Counting No of Students on the Collection";
            return msg;
        }
    }

    public class Address
    {
        public string Name { get; set; }

        public string Street { get; set; }
        public string City { get; set; }

        public string State { get; set; }

        public string PostalCode { get; set; }
    }
}
