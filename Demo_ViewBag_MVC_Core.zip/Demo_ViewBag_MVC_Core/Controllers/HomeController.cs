﻿using Demo_ViewBag_MVC_Core.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Demo_ViewBag_MVC_Core.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpGet]
       public IActionResult SetViewBag(string value)
        {
            ViewBag.Message = value;
            return new EmptyResult();
        }
        [ViewData]

        public string Title { get; set; }
        public IActionResult Contact ()
        {
            ViewData["Message"] = "Yours Contact Details";
            var ViewModel = new Address()
            {
                Name = "Google India",
                Street = "Maker Maxity, Bandra Kurla Complex",
                City = "Mumbai",
                State = "Maharastra",
                PostalCode = "400051"
            };

            return View(ViewModel);
        }
    }
}
