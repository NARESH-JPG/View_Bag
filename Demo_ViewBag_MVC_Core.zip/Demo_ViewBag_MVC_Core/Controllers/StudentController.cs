﻿using Demo_ViewBag_MVC_Core.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo_ViewBag_MVC_Core.Controllers
{
    public class StudentController : Controller
    {
        IList<Student> StudentList = new List<Student>()
        {
            new Student() { StudentID =1, Studentname= "Raj", Age = 21},
            new Student() {StudentID = 2, Studentname= "Siya", Age = 22}
        };
        public IActionResult Index()
        {
            ViewBag.Total = StudentList.Count;
            
            return View();
        }
    }
}
